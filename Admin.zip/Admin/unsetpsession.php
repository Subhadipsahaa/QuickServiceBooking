<?php


        if (isset($_SESSION['add'])) {
                unset($_SESSION['add']);
                unset($_SESSION['service_name']);
            }
        

?>