<form name='del<?php echo $i ?>' method='post' action='#'>
    <input type='hidden' name='uid' value='<?php echo $rec['s_id'];  ?>'>
    <button type='submit' class='btn' style='width: 100%;height:100%;'><i class='fa-solid fa-pen-to-square'></i></button>
</form>